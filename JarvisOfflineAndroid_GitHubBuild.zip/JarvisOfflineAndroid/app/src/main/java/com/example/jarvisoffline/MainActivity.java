package com.example.jarvisoffline;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.*;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private TextView status, transcript, reply;
    private EditText input;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private boolean torchOn = false;
    private static final int REQ_AUDIO = 10, REQ_CAMERA = 11;
    private final String PREFS = "jarvis_notes";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault());
        });
        say("JARVIS online. Local command systems ready.");
        status.setText("SYSTEM ONLINE • OFFLINE COMMAND MODE");
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 32, 24, 24);
        page.setBackgroundColor(0xFF06111D);

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S.");
        title.setTextColor(0xFF42D9FF);
        title.setTextSize(34);
        title.setLetterSpacing(0.16f);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, 70));

        status = label("INITIALISING...", 13, 0xFF77E8FF);
        status.setGravity(Gravity.CENTER);
        page.addView(status);

        TextView orb = label("◉", 76, 0xFF42D9FF);
        orb.setGravity(Gravity.CENTER);
        page.addView(orb, new LinearLayout.LayoutParams(-1, 125));

        transcript = label("YOU: Awaiting input", 15, 0xFFB9DCE8);
        page.addView(transcript);
        reply = label("JARVIS: Systems standing by.", 17, 0xFFFFFFFF);
        reply.setPadding(0, 18, 0, 18);
        page.addView(reply);

        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Enter a command...");
        input.setHintTextColor(0xFF66808D);
        input.setTextColor(0xFFFFFFFF);
        input.setPadding(14, 12, 14, 12);
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF42D9FF));
        page.addView(input, new LinearLayout.LayoutParams(-1, 56));

        Button run = button("EXECUTE COMMAND");
        page.addView(run);
        run.setOnClickListener(v -> {
            String command = input.getText().toString().trim();
            input.setText("");
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(input.getWindowToken(), 0);
            handle(command);
        });

        Button mic = button("🎙  VOICE COMMAND");
        page.addView(mic);
        mic.setOnClickListener(v -> startListening());

        Button help = button("COMMAND HELP");
        page.addView(help);
        help.setOnClickListener(v -> respond("Try: time, date, battery, flashlight on, flashlight off, open settings, save note [text], read note, clear note."));

        TextView footer = label("LOCAL-FIRST • NO ACCOUNT • NO CLOUD AI", 10, 0xFF547382);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = 24;
        page.addView(footer, fp);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }

    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(0xFF06111D);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF42D9FF));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 52);
        p.topMargin = 10;
        b.setLayoutParams(p);
        return b;
    }
    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Speech recognition is not available on this phone. You can still type commands.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("LISTENING..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("PROCESSING..."); }
            public void onError(int e) { status.setText("READY"); respond("I couldn't recognise that. Please try again or type your command."); }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) handle(r.get(0));
                status.setText("SYSTEM ONLINE • OFFLINE COMMAND MODE");
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        recognizer.startListening(i);
    }
    private void handle(String raw) {
        if (raw == null || raw.trim().isEmpty()) return;
        String c = raw.trim().toLowerCase(Locale.ROOT);
        transcript.setText("YOU: " + raw);
        if (c.equals("time") || c.contains("what time")) {
            respond("The time is " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date()));
        } else if (c.equals("date") || c.contains("what date") || c.contains("today's date")) {
            respond("Today is " + new SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(new Date()));
        } else if (c.contains("battery")) {
            IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent b = registerReceiver(null, f);
            int level = b == null ? -1 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = b == null ? 100 : b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            respond(level < 0 ? "Battery information is unavailable." : "Battery level is " + (level * 100 / scale) + " percent.");
        } else if (c.contains("flashlight on") || c.contains("torch on")) {
            setTorch(true);
        } else if (c.contains("flashlight off") || c.contains("torch off")) {
            setTorch(false);
        } else if (c.startsWith("open ")) {
            openApp(c.substring(5).trim());
        } else if (c.startsWith("save note ")) {
            String note = raw.substring(Math.min(10, raw.length())).trim();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("note", note).apply();
            respond("Note saved on this phone.");
        } else if (c.contains("read note")) {
            String note = getSharedPreferences(PREFS, MODE_PRIVATE).getString("note", "");
            respond(note.isEmpty() ? "There are no saved notes." : "Your saved note is: " + note);
        } else if (c.contains("clear note")) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("note").apply();
            respond("Saved note cleared.");
        } else if (c.equals("help") || c.contains("what can you do")) {
            respond("I can tell the time and date, check battery, control the flashlight, open apps, and save or read a note. Say command help for examples.");
        } else {
            respond("I don't have an offline command for that yet. Say command help to hear supported commands.");
        }
    }
    private void openApp(String name) {
        String pkg = null;
        if (name.contains("settings")) pkg = "com.android.settings";
        else if (name.contains("camera")) pkg = "com.android.camera";
        else if (name.contains("phone") || name.contains("dialer")) pkg = "com.android.dialer";
        else if (name.contains("calculator")) pkg = "com.android.calculator2";
        else if (name.contains("browser") || name.contains("chrome")) pkg = "com.android.chrome";
        if (pkg == null) { respond("I don't know that app shortcut yet."); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) { respond("That app isn't available under the expected package name."); return; }
        try { startActivity(launch); respond("Opening " + name + "."); }
        catch (Exception e) { respond("I couldn't open that app."); }
    }
    private void setTorch(boolean on) {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            respond("Please grant camera permission, which Android requires for flashlight control.");
            return;
        }
        try {
            CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
            String[] ids = cm.getCameraIdList();
            if (ids.length == 0) { respond("No camera flash was found."); return; }
            cm.setTorchMode(ids[0], on);
            torchOn = on;
            respond(on ? "Flashlight switched on." : "Flashlight switched off.");
        } catch (Exception e) { respond("Flashlight control is not supported on this device."); }
    }
    private void respond(String s) {
        reply.setText("JARVIS: " + s);
        say(s);
    }
    private void say(String s) {
        if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }
    @Override public void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
