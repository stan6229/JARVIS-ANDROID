JARVIS OFFLINE — Android Studio project

Included:
- Futuristic local assistant interface
- Offline command parser for time/date/battery/notes/flashlight/app shortcuts
- Android text-to-speech
- Voice input requests Android speech recognition with EXTRA_PREFER_OFFLINE=true
- No internet permission and no cloud AI

Important limitations:
- Voice recognition is only offline if the phone has an offline speech-recognition service/language pack installed. Android may otherwise require connectivity or fail.
- This is a command-based assistant, not a full conversational LLM.
- App shortcuts vary by Android manufacturer and installed apps.
- Flashlight and microphone features ask for Android permissions when needed.

Build:
1. Extract this ZIP on a computer.
2. Open Android Studio.
3. Choose Open and select the extracted JarvisOffline folder.
4. Allow Gradle sync (first setup may need internet to download Android Gradle Plugin/SDK).
5. Connect your Android phone with USB debugging enabled, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to the phone and install it. Android may ask you to allow installs from that file manager.

Target: Android 8.0+; compile SDK 35; Java; no external libraries.


BUILD WITHOUT ANDROID STUDIO (GitHub Actions):
1. Create/sign in to a GitHub account in a browser.
2. Create a new repository. Upload the contents of this project folder (not the ZIP itself).
3. Make sure .github/workflows/build-apk.yml is included.
4. Open the repository's Actions tab and select "Build JARVIS APK".
5. Choose "Run workflow". Wait for the workflow to finish successfully.
6. Open the completed run and download the "JARVIS-Offline-debug-APK" artifact.
7. Extract the downloaded artifact ZIP; it contains app-debug.apk. Transfer it to the phone and install it.

This produces an unsigned-for-release, debug-signed APK suitable for personal testing/installing.
